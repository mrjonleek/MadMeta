<?php
# MadAbyss	          	          	          	    
# Copyright (C) 2012 Web.Paper.Scissors.# Homepage   : www.webpaperscissors.com 
# Author     : Jonathan Leek	    	
# Email      : devers@webpaperscissors.com 
# Version    : 1.0.0                     
# License    : http://www.gnu.org/copyleft/gpl.html GNU/GPL          
######################################################################
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin');
jimport( 'joomla.html.parameter');
class plgSystemMadmeta extends JPlugin
{
	function plgSystemMadmeta(&$subject, $config)
	{
		parent::__construct($subject, $config);
		$this->_plugin = JPluginHelper::getPlugin( 'system', 'madmeta' );
		$this->_params = new JParameter( $this->_plugin->params );
	}
	function onAfterRender()
	{
		$mainframe = &JFactory::getApplication();		$buffer = JResponse::getBody();				$meta_block = null;				for( $i=1; $i<=5; $i++) {			$name = trim(htmlentities($this->params->get('meta'.$i.'_name')));			$content = trim(htmlentities($this->params->get('meta'.$i.'_content')));			if($name && $content)				$meta_block .= '<meta name="'.$name.'" content="'.$content.'" />'."\r\n";						}								$meta_block = '<!-- Start MadMeta -->'."\r\n".$meta_block.'<!-- End MadMeta-->';		if($this->params->get('credit') == 1)			$sig = '<span style="font-size:75%!important;position:fixed;bottom:0;left:0;"><a href="http://www.madabyss.com">MadMeta Manager by MadAbyss</a></span>';					
		$buffer = str_replace ("<head>", "<head>"."\r\n".$meta_block, $buffer);		$buffer = str_replace ("</body>", $sig."\r\n"."</body>", $buffer);
		JResponse::setBody($buffer);		
		return true;
	}
}
?>